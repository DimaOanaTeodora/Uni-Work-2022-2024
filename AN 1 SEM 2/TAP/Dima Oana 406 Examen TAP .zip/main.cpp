/*
 * DIMA OANA TEODORA 406 S 1)
 * the nodes are labeled from 0 to n - 1
 *
 * Time complexity explanation of the code:

* The construction of the graph -> O(m) because of the adiacency list
* Computing the cardinalities -> O(m)
* MCS:
   Using priority queue
   Worst case scenario: all nodes are added to the priority queue -> O(n log n)
   While loop depends on the number of edges m .
   In each iteration, the node with min cardinality is deleted from PQ,
   And then it updates the cardinalities of its neighbors, and pushes them into PQ if they weren't visited.
   => O(m)

* Total:
 O(m + m + n log n) => O(m + n log n) (worst case) => O (m + n) (best case)

 *
 * */
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <queue>

using namespace std;

class Graph {
private:
    int n; // nodes
    int m; // edges
    vector<vector<int>> edges;
    vector<int> sorted;

    struct Compare {
        bool operator()(const pair<int, int>& p1, const pair<int, int>& p2) {
            // used for ordering in priority queue
            return p1.first > p2.first;
        }
    };

public:
    Graph(int n, int m) : n(n), m(m), edges(n){}
    Graph(): n(0), m(0), edges(0) {}
    Graph (Graph & graph){
        // copy constructor
        m = graph.m;
        n = graph.n;
        edges = graph.edges;
    }
    ~Graph(){
        n =0;
        m = 0;
        edges.clear();
    }

    void insertEdge(int u, int v) {
        // add edge
        edges[u].push_back(v);
        edges[v].push_back(u);
    }

    int size(){
        // get number of nodes
        return n;
    }

    vector<int> getSorted(){
        // return MCS sorting
        return sorted;
    }

    void printDebug() {
        // only for debugging purpose **
        // print graph
        cout << "Debug only: print the adiancecy list of the current graph object: \n";
        for (int u = 0; u < n; u++) {
            cout << "Node " << u << ": ";
            for (int v : edges[u]) {
                cout << v << " ";
            }
            cout << "\n";
        }
    }

    void MCS() {
        // priority queue --> select the nodes with min cardinality
        // each item is a pair  {cardinality, node}
        priority_queue<pair<int, int>, vector<pair<int, int>>,Compare> pq;

        vector<int> cardinalities(n, 0);

        // calculate the cardinalities for each node
        for (int i = 0; i < n; i++) {
            vector<int> neighbours = edges[i];
            for (int j = 0; j < neighbours.size(); j++) {
                cardinalities[neighbours[j]] = cardinalities[neighbours[j]] + 1;
            }
        }

        // start ---> node 0 -> priority queue
        pq.push({cardinalities[0], 0});

        vector<int> visited(n, 0);
        while (pq.size() >0 ) {
            /*
             * each time it is selected the node with the minimum cardinality
             * */

            int node = pq.top().second;
            pq.pop(); // remove the node

            if (visited[node] == 1) {
                continue;  // node is already visited
            }

            // update the cardinalities for the neighbors of the node
            vector<int> neighbours = edges[node];
            for (int i = 0; i < neighbours .size(); i++) {
                if (visited[neighbours[i]] == 0){ // if the node was not visited
                    pq.push({cardinalities[neighbours[i]], neighbours[i]});
                    cardinalities[neighbours[i]] =  cardinalities[neighbours[i]] - 1;
                }
            }

            sorted.push_back(node); // add node to the final solution
            visited[node] = 1; //  node is now visited -> skip next time
        }
    }
};

Graph* read() {
    /*
     * Reads a file and its content
     * Shows an error If the file can't be open
     * Returns the graph created
     */
    string filename;
    cout<<"Enter the filename: ";
    cin>>filename;
    cout<<"\n";

    Graph *graph;

    ifstream file(filename);
    if (file.is_open()) {
        int n, m, u, v;

        // read m, n first
        file >> n >> m;

        // create graph object
        graph = new Graph(n, m);

        for(int i = 0; i < m; i++ ) {
            // read edges
            file >>u >>v;
            graph->insertEdge(u, v);
        }
        file.close();
    }
    else{
        cout<<"Error the file can't be open :( \n";
    }
    return graph;
}

int main() {

    Graph *graph = read();
    graph -> printDebug();

    // calculate MCS
    graph -> MCS();
    vector<int> result = graph -> getSorted();

    cout << "MCS result: ";
    for(int i = 0; i < graph -> size(); i++){
        cout << result[i] << " ";
    }

    return 0;
}
